#!/bin/env python2

import numpy as np
import os



def get_VEL(sta, lon, lat):
    path = './taiwan_strait_20170712/'
    nlon = int(lon/0.25)
    nlat = int(lat/0.25)
    minlon = nlon*0.25; maxlon = (nlon+1)*0.25
    minlat = nlat*0.25; maxlat = (nlat+1)*0.25
    if -0.00001 < minlon % 1 < 0.00001:
        minlon = int(minlon)
    if -0.00001 < maxlon % 1 < 0.00001:
        maxlon = int(maxlon)
    if -0.00001 < minlat % 1 < 0.00001:
        minlat = int(minlat)
    if -0.00001 < maxlat % 1 < 0.00001:
        maxlat = int(maxlat)
    print 'minlon,maxlon, ', minlon,maxlon
    print 'minlat,maxlat, ', minlat,maxlat
    leftdown  = path + 'N' + str(minlon) +'_' + str(minlat) +'.ph'; 
    dist_leftdown = ((lon-minlon)**2 + (lat-minlat)**2)**0.5
    leftup    = path + 'N' + str(minlon) +'_' + str(maxlat) +'.ph';  
    dist_leftup = ((lon-minlon)**2 + (lat-maxlat)**2)**0.5
    rightdown = path + 'N' + str(maxlon) +'_' + str(minlat) +'.ph'; 
    dist_rightdown = ((lon-maxlon)**2 + (lat-minlat)**2)**0.5
    rightup   = path + 'N' + str(maxlon) +'_' + str(maxlat) +'.ph'; 
    dist_rightup = ((lon-maxlon)**2 + (lat-maxlat)**2)**0.5
    if os.path.exists(leftdown) and os.path.exists(leftup) and os.path.exists(rightdown) and os.path.exists(rightup):
        print leftdown; print leftup; print rightdown; print rightup
        print dist_leftdown; print dist_leftup; print dist_rightdown; print dist_rightup
        LD = np.loadtxt(leftdown); LU = np.loadtxt(leftup); RD = np.loadtxt(rightdown); RU = np.loadtxt(rightup)
        if LD.shape[0] == LU.shape[0] == RD.shape[0] == RU.shape[0]:
            print LD.shape[0]
            VEL = (LD*dist_leftdown + LU*dist_leftup + RD*dist_rightdown + RU*dist_rightup)/(dist_leftdown + dist_leftup + dist_rightdown + dist_rightup)
            outfile = sta + '.ph.disp'; print outfile
            np.savetxt(outfile, VEL, fmt = '%s')






STA = np.loadtxt('sta.lst', dtype = str); print STA
for sta, lon, lat in STA:
    print sta, lon, lat
    #outfile = sta + '.ph.disp'; print outfile
    get_VEL(sta, float(lon), float(lat)) 











