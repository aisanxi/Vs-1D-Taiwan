import sys
import os
import math
import string

# -------------------  get nper, ave[], period[]  ------------------------------------------------------------------------------
period=[]
ave = []
j = 0
for i in [  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 35, 40, 45 ]:
	fi=open("../" + str(i) + ".ave","r")
	ave.append(fi.readline().rstrip())
	fi.close()
	print ave[j]
	j = j + 1
	period.append(i)
nper = j



# --------------  get datav[], datar[], np  -----------------------------------------------------------------------------
datav = []
datar = []
np = 0
for i in [  8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 35, 40, 45]:
	
	j = 0
	eachper = []
#	fnm="/home/zhengyong/aisanxi/shanxi/Tomo_20161208/tomo_ph/" + str(i) + "/dt_850_100_50_10_1.5/dt_850_100_50_" + str(i) + ".1"
#        fnm="/home/zhengyong/aisanxi/shanxi/Tomo_20161208/tomo_ph/" + str(i) + "/used/dt_700_60_30_" + str(i) + ".1"
#	fnm="/home/zhengyong/aisanxi/shanxi/Tomo_used/ph/"+"dt_700_60_30_"+ str(i) + ".1"
	fnm="/home/zhengyong/aisanxi/taiwan_strait/Tomo.2017.07.10/tomo_ph/used/"+"dt_500_60_30_"+ str(i) + ".1"
	os.system("ls %s" % (fnm))
	fi=open(fnm, "r")
	for l in fi:
		ll = l.rstrip().split()
#		print ll
		eachper.append(ll)
		j = j + 1
	np = j
	datav.append(eachper)

        eachper = []
#        fnm="/home/zhengyong/aisanxi/shanxi/Tomo_20161208/tomo_ph/" + str(i) + "/dt_850_100_50_10_1.5/dt_850_100_50_" + str(i) + ".rea"
#        fnm="/home/zhengyong/aisanxi/shanxi/Tomo_20161208/tomo_ph/" + str(i) + "/used/dt_700_60_30_" + str(i) + ".rea"
#	fnm="/home/zhengyong/aisanxi/shanxi/Tomo_used/ph/"+"dt_700_60_30_"+ str(i) + ".rea"
	fnm="/home/zhengyong/aisanxi/taiwan_strait/Tomo.2017.07.10/tomo_ph/used/"+"dt_500_60_30_"+ str(i) + ".rea"
        os.system("ls %s" % (fnm))
        fi=open(fnm, "r")
        for l in fi:
                ll = l.rstrip().split()
                eachper.append(ll)
        datar.append(eachper)
print np, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
# --------------------  get sta[], nsta  ------------------------------------------------------------------------------------
sta = []
i = 0
stanm = "/home/zhengyong/aisanxi/shanxi/VS_INV/init_model/CREAT_MODEL/station_inv"
os.system("ls %s" % (stanm))
for l in open(stanm, "r"):
	sta.append(l.rstrip().split())
	i = i + 1
nsta = i

# ----------------------------------------------------------------------------------------------------------------------------

#for i in range(nsta):
#	fnm = sta[i][1] + ".ph"
#	print fnm
#	fo=open(fnm, "w")




for i in range(np):
	stanm = "N" + str(float(datav[0][i][0])) + "_" + str(float(datav[0][i][1])) + ".ph"
	if float(datav[0][i][0])%1.0 == 0 and float(datav[0][i][1])%1.0 ==0:
		a=float(datav[0][i][0])
		b=float(datav[0][i][1])
		print "a,b",a, b
		stanm = "N" + str(int(a)) + "_" + str(int(b)) + ".ph"

        if float(datav[0][i][0])%1.0 == 0 and float(datav[0][i][1])%1.0 !=0:
                a=float(datav[0][i][0])
                b=float(datav[0][i][1])
                print "a,b",a, b
                stanm = "N" + str(int(a)) + "_" + str(b) + ".ph"


        if float(datav[0][i][0])%1.0 != 0 and float(datav[0][i][1])%1.0 ==0:
                a=float(datav[0][i][0])
                b=float(datav[0][i][1])
                print "a,b",a, b
                stanm = "N" + str(a) + "_" + str(int(b)) + ".ph"

	print stanm
	fo=open(stanm,"w")
	for per in range(nper):
		r=datar[per][i][3]
		print "half resolution", r
		r=float(r)*2.0
		print "resolution", r
		av=ave[per]
		print "ave", av
		un = float(av)*((r/50.0)**0.5)
		
		fo.write("%g %s %g\n" % (period[per], datav[per][i][2], un))
	fo.close()
















